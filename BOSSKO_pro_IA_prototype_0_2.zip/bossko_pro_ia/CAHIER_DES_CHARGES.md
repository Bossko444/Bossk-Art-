# BOSSKO pro IA — Cahier des charges de référence

## Vision
Assistant personnel intelligent, stratégique et proactif, accessible par texte et voix, avec une application Android comme point d'entrée et une synchronisation multi-appareils.

## Identité et comportement
- Nom : BOSSKO pro IA ; symbole de marque : S ; univers graphique futuriste + premium.
- Ton naturel-professionnel, chaleureux, exigeant, encourageant, discret ; humour rare.
- Voix cible : masculine ivoirienne, débit normal ; français, expressions ivoiriennes/Nouchi, anglais et langues africaines selon disponibilité.
- Phrase de réveil souhaitée : « BOSSKO pro » ; écoute en arrière-plan à étudier selon les limites Android, avec indicateur visible et arrêt d'urgence.
- Autonomie encadrée : préparer et organiser seul ; demander confirmation avant les actions importantes.

## Interface
- Logo S, commande vocale centrale, conversation texte.
- Agenda, tâches, projets, finances en consultation, actualités/opportunités, météo, documents, statistiques, raccourcis.
- Tableau de bord organisé automatiquement et personnalisable.

## Modules
1. Assistant IA multi-modèles (OpenAI, Claude, Gemini selon intégrations/API et budgets).
2. Organisation quotidienne : rendez-vous, cours, formations, livres, prière/méditation, repas/hydratation, sport, projets, repos ; rappels et bilan du soir.
3. Veille : Côte d'Ivoire et international, entrepreneuriat, financements, appels à projets, concours, bourses, environnement, IA/technologie, économie, formation.
4. Entrepreneuriat : idées, études de marché, business plans, marketing, prospection, partenaires, équipe, risques, rentabilité.
5. Finance personnelle : budget, revenus/dépenses, épargne, objectifs, projections et analyse d'investissements — consultation seulement.
6. Éducation : tutorat, recherche, fiches, exercices, rédaction, langues et suivi des apprentissages.
7. Relations : rédaction adaptée, analyse de conversations, négociation, réseau, rappels de dates importantes.
8. Réseaux sociaux : idées, scripts, visuels, calendrier éditorial, statistiques et préparation de réponses ; publication sur confirmation.
9. Studio multimédia : affiches, logos, vidéos courtes, présentations, PDF, voix off, jingles originaux, infographies.
10. Fichiers : classement, dossiers par projet, recherche, résumé PDF/Word, création, conversion, doublons, sauvegardes, versions, photos/vidéos, notes/archives.
11. Mode hybride : consultation de données locales, tâches/notes hors ligne, file d'attente de demandes, IA locale simple si les ressources le permettent.

## Comptes à intégrer, sous réserve des API et autorisations
Google/Gmail, Drive, Agenda, Contacts, WhatsApp, WhatsApp Business, Facebook, Instagram, TikTok, LinkedIn, YouTube, Telegram, Microsoft/Outlook. Authentification OAuth officielle. Une connexion ne garantit pas toutes les fonctions d'une plateforme.

## Sécurité et règles non négociables
- Administrateur initial : propriétaire uniquement ; comptes collaborateurs ajoutables plus tard avec permissions limitées.
- Permissions Android et OAuth accordées explicitement, service par service et fonction par fonction.
- Aucun mot de passe, PIN bancaire ou OTP stocké.
- Finance : lecture/analyse/alertes uniquement. Interdiction technique d'initier transfert, paiement, retrait, changement de paramètres ou validation financière.
- Envois de messages, emails, SMS, appels, publications et modifications importantes : confirmation préalable, sauf réponses WhatsApp explicitement autorisées pour contacts préalablement listés et catégories définies.
- Ne pas répondre automatiquement dans un contexte sensible, juridique, financier, médical ou conflictuel.
- Enregistrements vocaux : ne pas conserver l'audio après traitement ; demander consentement avant traitement externe pour les conversations sensibles.
- Chiffrement, verrouillage PIN/biométrie, historique des actions, alertes d'accès inhabituel, arrêt d'urgence, sauvegardes contrôlées.
- Suppressions définitives : confirmation explicite.

## Architecture proposée
- Application Android native Kotlin/Jetpack Compose.
- Backend sécurisé pour orchestration IA, comptes, synchronisation et tâches planifiées.
- Base de données chiffrée et séparation des données par utilisateur.
- Connecteurs OAuth officiels ; secrets API conservés côté serveur, jamais dans l'application mobile.
- Mode local pour fonctions simples ; fonctions cloud et recherche web nécessitent Internet.

## Limites à traiter honnêtement
- L'écoute permanente par mot-clé est soumise aux restrictions Android, à la batterie, au microphone et aux politiques système ; ne pas promettre une écoute continue invisible.
- WhatsApp personnel, réseaux sociaux et applications tierces ont des API et règles d'accès limitées.
- Les intégrations Claude/Gemini/OpenAI peuvent entraîner des coûts d'API.
- Cette livraison est un prototype de démarrage, pas une application complète connectée ni un APK signé prêt à installer.
