package com.bosskopro.ia

import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0A1020)
private val Panel = Color(0xFF151F35)
private val Cyan = Color(0xFF58D7E8)
private val Gold = Color(0xFFD9B66F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BosskoApp() }
    }
}

@Composable
fun BosskoApp() {
    val context = LocalContext.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(context) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { initStatus ->
            val readyEngine = engine
            if (initStatus == TextToSpeech.SUCCESS && readyEngine != null) {
                val ivorianFrench = Locale("fr", "CI")
                readyEngine.language = if (readyEngine.isLanguageAvailable(ivorianFrench) >= TextToSpeech.LANG_AVAILABLE) ivorianFrench else Locale.FRENCH
            }
        }
        tts = engine
        onDispose { engine?.stop(); engine?.shutdown(); tts = null }
    }
    var typed by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Prêt à vous assister") }
    var lastCommand by remember { mutableStateOf("Bienvenue. Je suis BOSSKO pro IA.") }
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            lastCommand = spoken
            val reply = localReply(spoken)
            status = "Réponse locale — aucune connexion IA requise"
            tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "bossko-local-reply")
        } else status = "Aucune commande reconnue"
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, secondary = Gold, background = Navy, surface = Panel,
        onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
    )) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, Color(0xFF101D34), Navy)))) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
                contentPadding = PaddingValues(top = 28.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(52.dp).background(Brush.linearGradient(listOf(Cyan, Gold)), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                            Text("S", color = Navy, fontSize = 32.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("BOSSKO pro IA", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Votre assistant personnel intelligent", fontSize = 12.sp, color = Cyan)
                        }
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.Shield, contentDescription = "Sécurité", tint = Gold)
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("VOTRE ASSISTANT", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Spacer(Modifier.height(14.dp))
                            Box(Modifier.size(116.dp).background(Brush.radialGradient(listOf(Cyan, Color(0xFF22617A), Panel)), CircleShape), contentAlignment = Alignment.Center) {
                                IconButton(onClick = {
                                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-CI")
                                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez à BOSSKO pro")
                                    }
                                    try { voiceLauncher.launch(intent) } catch (_: Exception) { status = "Reconnaissance vocale indisponible sur cet appareil" }
                                }, modifier = Modifier.size(88.dp).background(Color(0xFF0B2435), CircleShape)) {
                                    Icon(Icons.Default.Mic, contentDescription = "Parler à BOSSKO", tint = Cyan, modifier = Modifier.size(42.dp))
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Text("Appuyez pour parler", color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(status, color = Cyan, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Text("ESPACE DE CONVERSATION", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(lastCommand, color = Color.White)
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(value = typed, onValueChange = { typed = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Écrivez votre demande…") }, singleLine = true)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { if (typed.isNotBlank()) { val request = typed; lastCommand = request; typed = ""; val reply = localReply(request); status = "Réponse locale — moteur IA en ligne à connecter"; tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "bossko-text-reply"); lastCommand = "$request\n\nBOSSKO : $reply" } }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Send, contentDescription = null)
                                Spacer(Modifier.width(8.dp)); Text("Envoyer")
                            }
                        }
                    }
                }
                item { SectionTitle("VOTRE QUOTIDIEN") }
                item { DashboardGrid(listOf("Agenda & rendez-vous" to Icons.Default.CalendarMonth, "Tâches & rappels" to Icons.Default.TaskAlt, "Projets professionnels" to Icons.Default.Work, "Budget & épargne" to Icons.Default.AccountBalanceWallet)) }
                item { SectionTitle("INTELLIGENCE & RESSOURCES") }
                item { DashboardGrid(listOf("Actualités & opportunités" to Icons.Default.Public, "Documents & archives" to Icons.Default.FolderOpen, "Statistiques & rapports" to Icons.Default.Insights, "Applications connectées" to Icons.Default.Apps)) }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF17283A)), shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, tint = Cyan, contentDescription = null)
                            Spacer(Modifier.width(10.dp))
                            Text("Version 0.2 : réponses vocales locales de démonstration. Le moteur IA en ligne, le mot de réveil permanent et les comptes connectés restent à intégrer.", color = Color(0xFFD5E2EF), fontSize = 12.sp)
                        }
                    }
                }
                item { Text("BOSSKO pro IA • Prototype 0.2", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally)) }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
}

@Composable
private fun DashboardGrid(items: List<Pair<String, androidx.compose.ui.graphics.vector.ImageVector>>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowItems.forEach { (label, icon) ->
                    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(icon, contentDescription = null, tint = Cyan, modifier = Modifier.size(24.dp))
                            Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}


private fun localReply(input: String): String {
    val q = input.lowercase(Locale.ROOT)
    return when {
        listOf("bonjour", "salut", "hello", "bonsoir").any { q.contains(it) } ->
            "Bonjour ! Je suis BOSSKO pro. Je suis disponible. Que puis-je faire pour vous ?"
        q.contains("heure") -> "Il est actuellement " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        q.contains("date") || q.contains("quel jour") -> "Nous sommes le " + SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRENCH).format(Date())
        q.contains("qui es-tu") || q.contains("présente-toi") ->
            "Je suis BOSSKO pro IA, votre assistant personnel. En mode local, mes réponses sont limitées. Connectez-moi à mon moteur intelligent pour les analyses avancées."
        q.contains("aide") ->
            "Je peux déjà répondre à quelques commandes simples hors ligne. Pour les recherches, les actualités et les analyses avancées, une connexion Internet et le moteur IA seront nécessaires."
        else ->
            "J'ai bien reçu votre demande. Mon mode local de démonstration ne sait pas encore traiter cette question. Le moteur IA connecté sera nécessaire pour vous répondre précisément."
    }
}
