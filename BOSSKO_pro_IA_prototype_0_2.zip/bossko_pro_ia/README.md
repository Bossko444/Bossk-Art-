# BOSSKO pro IA — prototype Android 0.2

Projet Android natif Kotlin + Jetpack Compose.

## Ce qui fonctionne dans cette version
- Interface d'accueil et tableau de bord de démonstration.
- Reconnaissance vocale déclenchée par le bouton micro via le service vocal Android.
- Réponses locales prédéfinies pour quelques commandes simples (salutations, heure, date, aide).
- Lecture des réponses avec la synthèse vocale Android (TTS).
- Saisie texte avec réponse locale de démonstration.

## Limites importantes
- Ce n'est pas encore un assistant IA général : aucun modèle distant ni backend n'est connecté.
- La reconnaissance vocale dépend du moteur installé sur Android et peut nécessiter Internet. La synthèse vocale peut fonctionner hors ligne si une voix française est installée.
- Le mot de réveil permanent « BOSSKO pro » n'est pas implémenté. Il nécessitera un service Android dédié, une stratégie de batterie et des tests sur l'appareil.
- L'application ne peut pas contourner l'écran de verrouillage ni déverrouiller le téléphone à la place du système Android.
- Les comptes OAuth, WhatsApp, réseaux sociaux, synchronisation, notifications et mémoire sécurisée restent à développer.
- Ne pas saisir de données confidentielles dans ce prototype.

## Construction
Ouvrir le dossier dans Android Studio, laisser Gradle synchroniser, puis compiler l'application pour un appareil Android (minSdk 26).
Les clés API ne doivent jamais être intégrées dans l'APK : elles devront rester dans un backend sécurisé.
